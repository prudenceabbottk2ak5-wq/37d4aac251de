// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Integrate with RK4");
  std::fflush(stdout);
  return lionss_run_workload("rk4_adaptive");
}
