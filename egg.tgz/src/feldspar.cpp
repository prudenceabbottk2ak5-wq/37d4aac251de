// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Grow feldspar twin\n", stdout);
  return lionss_run_workload("feldspar");
}
