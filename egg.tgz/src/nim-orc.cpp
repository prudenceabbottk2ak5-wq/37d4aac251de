// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Collect cyclic refs\n", stdout);
  return lionss_run_workload("nim-orc");
}
