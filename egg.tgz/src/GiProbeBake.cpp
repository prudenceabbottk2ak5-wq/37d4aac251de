// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Bake GI probes\n", stdout);
  return lionss_run_workload("GiProbeBake");
}
