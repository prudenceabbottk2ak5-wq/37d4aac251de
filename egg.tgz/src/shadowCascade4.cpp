// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Bake shadow cascades\n", stdout);
  return lionss_run_workload("shadowCascade4");
}
