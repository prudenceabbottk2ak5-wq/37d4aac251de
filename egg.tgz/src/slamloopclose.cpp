// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Close loop constraints\n", stdout);
  return lionss_run_workload("slamloopclose");
}
